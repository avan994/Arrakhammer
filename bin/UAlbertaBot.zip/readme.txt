To Compile:
- Open src/UAlbertaBot/VisualStudio/UAlbertaBot.sln in VS2013
- Select Release mode
- Build the UAlbertaBot project
- Output will go to src/UAlbertaBot/bin/UAlbertaBot.dll

Tournament Setup:
- Copy dll/UAlbertaBot.dll (or the above compiled dll) to the tournament UAlbertaBot/AI folder
- Copy dll/UAlbertaBot_Config.txt to the tournament UAlbertaBot/AI folder
