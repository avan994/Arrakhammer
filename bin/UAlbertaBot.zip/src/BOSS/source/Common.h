#pragma once

#include "BWAPI.h"
#include <stdio.h>
#include <math.h>
#include <fstream>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <limits>

#include "BOSSAssert.h"
#include "BaseTypes.h"
#include "Constants.h"